---
title: Common issues
sidebar_label: Common issues
description: Troubleshooting Booking Engine Connector verify connection sync checkout cron fallback quotes empty booking button missing.
---

# Common issues

Quick symptom → cause → fix matrix for typical WordPress admins.

| Symptom | Likely cause | What to try |
|---------|--------------|-------------|
| **Verify connection fails** | Wrong credential, typo, firewall blocking outbound HTTPS | Re-copy secrets from Kross, test from another network/VPN, ask hosting to allow `api.krossbooking.com`. |
| **No units after sync** | Credentials incomplete or remote inventory empty | Read sync notice errors, confirm Hotel ID maps to active rooms in Kross. |
| **Many units “skipped”** | Units flagged **sync disabled** (`bec_sync_enabled`) | Inspect unit metabox inspector—manually sync row action still refreshes single rows when needed. |
| **Booking button missing** | Incomplete dates / checkout base URL missing / POST checkout lacking rate ID | Confirm URL params present, fill **Booking engine base URL**, pick GET temporarily to validate flow. |
| **Quotes always empty** | Dates invalid vs provider rules or occupancy exceeds limits | Adjust guests, widen stay window, inspect **[API Log](./02-using-the-api-log.md)** for calendar responses. |
| **Cron feels delayed** | Low-traffic WP-Cron | Trigger visits manually or rely on server cron hitting `wp-cron.php`; run **Run sync now** occasionally. |
| **Gallery duplicates / odd filenames** | Prefix/suffix changed mid-project | Run rename tools documented under **[Gallery images](../04-units/04-gallery-images.md)** carefully during quiet hours. |
| **Shows neither fallback nor checkout on errors** | Fallback triggers exclude error category | Adjust categories under **Checkout & fallback** or consult developer filters (`bec_booking_error_notice_html`). |
| **`[bec_unit_info]` empty** | Wrong key or stale payload | Re-sync unit, confirm renderer key spelling—see **[bec_unit_info](../06-shortcodes/08-bec-unit-info.md)**. |

---

## Still stuck?

Collect:

1. Plugin version (`[bec_version]`).
2. Redacted screenshot of Connection settings (hide secrets).
3. One **[API Log](./02-using-the-api-log.md)** row showing failing endpoint + HTTP status.

<!-- SCREENSHOT: Example API log row highlighting status column -->
![API log sample row](./../img/08-troubleshooting/api-log-sample-row.png)
